# Sass Portfolio Tutorial
This is part of my Sass tutorial on YouTube.

Tutorial Link : https://youtu.be/_a5j7KoflTs

Demo Website  : https://codestackr.github.io/portfolio-sass/dist/
